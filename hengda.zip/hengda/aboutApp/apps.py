from django.apps import AppConfig


class AboutappConfig(AppConfig):
    name = 'aboutApp'
    verbose_name = '公司简介'
