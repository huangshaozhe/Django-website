from django.apps import AppConfig


class ServiceappConfig(AppConfig):
    name = 'serviceApp'
    verbose_name = "服务支持"
