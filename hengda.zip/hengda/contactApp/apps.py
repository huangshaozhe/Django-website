from django.apps import AppConfig


class ContactappConfig(AppConfig):
    name = 'contactApp'
    verbose_name = "人才招聘"
