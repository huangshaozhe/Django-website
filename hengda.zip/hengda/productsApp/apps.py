from django.apps import AppConfig


class ProductsappConfig(AppConfig):
    name = 'productsApp'
    verbose_name = '产品中心'
