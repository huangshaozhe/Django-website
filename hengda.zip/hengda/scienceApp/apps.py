from django.apps import AppConfig


class ScienceappConfig(AppConfig):
    name = 'scienceApp'
