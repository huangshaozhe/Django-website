"""
    -*- coding: utf-8 -*-
    @Time    : 2021/4/3 15:14
    @Author  : zhongxiaoting
    @Site    : 
    @File    : fenye.py
    @Software: PyCharm
"""
from django.core.paginator import Paginator
from django.http import request

from productsApp import views
from productsApp.models import Product




